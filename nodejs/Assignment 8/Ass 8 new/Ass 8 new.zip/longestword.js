var str="Web Development Tutorial";
var arr=str.split(" ");
var word,x=0;
arr.forEach(long);
console.log(word);
function long(str1)
{
	var a=str1.length;
	if(a>x)
	{
		word=str1;
		x=a;
	}
}